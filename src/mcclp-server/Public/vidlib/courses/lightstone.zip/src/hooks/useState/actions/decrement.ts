import { Action, State } from "lightstone-types";

export function decrement (state: State, action: Action) {
    return {count: state.count - 1};
}