import React from 'react';
import { Count } from "lightstone-components";
import { StateProvider } from "lightstone-hooks/useState";
import logo from './logo.svg';
import './App.css';

function App() {

  return (
    <StateProvider>
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <Count></Count>
        </header>
      </div>
    </StateProvider>
  );
}

export default App;
