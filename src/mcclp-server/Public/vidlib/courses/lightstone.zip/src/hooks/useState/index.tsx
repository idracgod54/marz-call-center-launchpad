import { useReducer, createContext, useContext } from "react";
import { Action, ContextProviderProps, Dispatch, State } from "lightstone-types/state";
import * as actions from "./actions";

const StateContext = createContext<
    {state: State; dispatch: Dispatch} | undefined
>(undefined);

function StateProvider({children}: ContextProviderProps) {
    const initialState = {
        count: 0
    };
    const [state, dispatch] = useReducer((state: State, action: Action) => {
        if (!actions[action.type]) {
            throw new Error(`No action called "${action.type}" was found.`);
        }
        return actions[action.type](state, action);
    }, initialState);
    const value = {state, dispatch};
    return (
        <StateContext.Provider value={value}>
            {children}
        </StateContext.Provider>
    );
}

function useState() {
    const context = useContext(StateContext);
    if (context === undefined) {
        throw new Error("useState must be used within a StateProvider");
    }
    return context;
}

export { StateProvider, useState };