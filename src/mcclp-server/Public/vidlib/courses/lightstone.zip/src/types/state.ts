import { ReactNode } from "react";

export type Action = {type: "increment"} | {type: "decrement"};

export type Dispatch = (action: Action) => void;

export type State = {count: number};

export type ContextProviderProps = {children: ReactNode};