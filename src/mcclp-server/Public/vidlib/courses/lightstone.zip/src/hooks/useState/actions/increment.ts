import { Action, State } from "lightstone-types";

export function increment (state: State, action: Action) {
    return {count: state.count + 1};
}