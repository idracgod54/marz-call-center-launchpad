import React from "react";
import { useState } from "lightstone-hooks";

import "./styles.css";

function Count() { 
    const { state, dispatch } = useState();

    return (
        <div>
            <button onClick={() => dispatch({type:"decrement"})}>-</button>
            <h1>Count: {state.count}</h1>
            <button onClick={() => dispatch({type:"increment"})}>+</button>
        </div>
    );
}

export default Count;